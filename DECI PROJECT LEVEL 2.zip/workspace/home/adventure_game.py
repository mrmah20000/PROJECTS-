import time
import random


def print_pause(text):
    print(text)
    time.sleep(2)


def play_again():
    while True:
        choice = input("Do you want to play again? (y/n): ").lower()
        if choice in ["y", "n"]:
            return choice == "y"
        else:
            print("Invalid input. Please enter 'y' or 'n'.")


def game():
    score = 0
    print_pause('You live in a fantasy forest with your family')
    print_pause('Unfortunately, your parents died')
    print_pause('Your father told you to go to your uncle before his death')
    print_pause('You live in a world filled with monsters')
    print_pause('Start your journey across the forest to find your uncle')
    print_pause('Enter 1 if you want to go by boat')
    print_pause('Enter 2 if you want to go by horse')

    while True:
        number = input("Enter the number\n")
        if number == '1':
            score += 5
            print_pause('Your score is')
            print_pause(score)
            score = boat(score)
            break
        elif number == '2':
            score += 2
            print_pause('Your score is')
            print_pause(score)
            score = horse(score)
            break
        else:
            print_pause("Wrong number, try again")

    if not play_again():
        print("Thank you for playing! ")
        return

    game()


def boat(score):
    print_pause("You decide to go by boat")
    print_pause('You encounter fantasy crocodiles')
    print_pause('Enter 1 if you will fight by sword')
    print_pause('Enter 2 if you will fight by bow')

    while True:
        number = input("Enter the number\n")
        if number == '1':
            score += 5
            print_pause('Your score is')
            print_pause(score)
            kill_crocodiles_by_sword()
            score = after_kill_crocodiles_by_sword(score)
            break
        elif number == '2':
            score += 1
            print_pause('Your score is')
            print_pause(score)
            kill_crocodiles_by_bow()
            score = after_kill_crocodiles_by_bow(score)
            break
        else:
            print_pause("Wrong number, try again")

    return score


def horse(score):
    print_pause('You decide to go by horse')
    print_pause('You encounter a large monkey')
    print_pause('Enter 1 if you will sneak past quietly')
    print_pause('Enter 2 if you will give him a banana')

    while True:
        number = input("Enter the number\n")
        if number == '1':
            score -= 5
            print_pause('Your score is')
            print_pause(score)
            sneak_past_quietly()
            break
        elif number == '2':
            score += 4
            print_pause('Your score is')
            print_pause(score)
            give_him_banana()
            score = navigate_forest(score)
            print_pause('Enter 1 if you will climb tree')
            print_pause('Enter 2 if you will stand on ground')

            while True:
                number = input("Enter the number\n")
                if number == '1':
                    score += 3
                    print_pause('Your score is')
                    print_pause(score)
                    climb_tree()
                    score = reach_uncle(score)
                    break
                elif number == '2':
                    print_pause('Your score is')
                    print_pause(score)
                    stand_on_ground()
                    break
                else:
                    print_pause("Wrong number, try again")
            break
        else:
            print_pause("Wrong number, try again")

    return score


def kill_crocodiles_by_sword():
    print_pause("Crocodiles damage your boat")
    print_pause('You kill them hardly')
    print_pause('You continue on foot')


def kill_crocodiles_by_bow():
    print_pause('You kill them easily')
    print_pause('They do not damage your boat')
    print_pause('You continue by boat')


def sneak_past_quietly():
    print_pause("You try to sneak past the monkey")
    print_pause("The monkey notices you and attacks")
    print_pause("YOU LOSE")


def give_him_banana():
    print_pause('You give him a banana')
    print_pause('The monkey gladly accepts the banana and lets you pass')


def after_kill_crocodiles_by_sword(score):
    print_pause('You walk in the forest')
    print_pause('You are nearly at your uncle\'s place')
    print_pause('You want to rest before you continue')
    print_pause('You see a strange home to your left')
    print_pause('You see a cave to your right')
    print_pause('Enter 1 if you will go to the cave')
    print_pause('Enter 2 if you will go home')
    while True:
        number = input("Enter the number\n")
        if number == '1':
            score += 5
            print_pause('Your score is')
            print_pause(score)
            cave(score)
            break
        elif number == '2':
            score += 3
            print_pause('Your score is')
            print_pause(score)
            print_pause("You decide to go to the home and it's locked...")
            print_pause("You realize you need to continue your journey.")
            print_pause('Your score is')
            print_pause(score)
            home(score)
            break
        else:
            print_pause("Wrong number, try again")

    return score


def after_kill_crocodiles_by_bow(score):
    print_pause("You continue with your boat")
    print_pause('You arrive at a strange place')
    print_pause('You find a guide who puts you on the right path')
    print_pause('You encounter some bandits who want to steal from you')
    print_pause('You give them some money and they let you go')
    print_pause('You encounter the forest\'s boss monster')

    boss_encounter = random.randint(1, 2)
    if boss_encounter == 1:
        print_pause('You choose 1 randomly')
        score -= 4
        print_pause(f'Your score is: {score}')
        fight_the_monster()
    else:
        print_pause('You choose 2 randomly')
        score += 2
        print_pause(f'Your score is: {score}')
        escape_from_the_monster()


def cave(score):
    print_pause('You enter the cave')
    print_pause('You find a big monster')

    print_pause('Enter 1 if you will fight by sword')
    print_pause('Enter 2 if you will fight by bow')

    while True:
        number = input("Enter the number\n")
        if number == '1':
            score += 7
            print_pause('Your score is')
            print_pause(score)
            sword_in_cave(score)
            break
        elif number == '2':
            score -= 5
            print_pause('Your score is')
            print_pause(score)
            bow_in_cave()
            break
        else:
            print_pause("Wrong number, try again")


def home(score):
    print_pause("You go to the home and it's locked")
    print_pause("You need to continue your journey...")
    print_pause('Your score is')
    print_pause(score)
    cave(score)


def climb_tree():
    print_pause("You climb up a tree to escape the bear")
    print_pause("The bear cannot reach you")
    print_pause("You wait until the bear loses interest and leaves")
    print_pause("You continue on your journey")


def stand_on_ground():
    print_pause("You decide to stand your ground and fight the bear...")
    print_pause("The bear overpowers you and you lose the fight.")
    print_pause("YOU LOSE")


def sword_in_cave(score):
    print_pause("You kill the monster and find a key to the home")
    print_pause('You go back to the home')
    print_pause('You find a bed')
    print_pause('You rest')
    print_pause('After resting, you continue your journey')
    reach_uncle(score)


def bow_in_cave():
    print_pause('The monster kills you')
    print_pause('YOU LOSE')


def fight_the_monster():
    print_pause('You fight the monster')
    print_pause('It kills you because it is powerful')
    print_pause('YOU LOSE')


def escape_from_the_monster():
    print_pause('You escape from the monster')
    print_pause('It chases you')
    print_pause('You meet your uncle during the chase')
    print_pause('You and your uncle fight and kill the monster')
    print_pause('YOU WIN')


def navigate_forest(score):
    print_pause("You navigate through the dense forest")
    print_pause("Suddenly, you hear a growl behind you")
    print_pause("You turn around and see a bear charging towards you")
    return score


def reach_uncle(score):
    print_pause("You finally arrive at your uncle's house!")
    print_pause("He welcomes you warmly and offers you a warm meal.")
    print_pause('YOU WIN')
    print_pause('Your score is')
    print_pause(score)


game()
